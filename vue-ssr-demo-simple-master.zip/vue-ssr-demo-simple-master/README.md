> The simplest possible Vue 2.0 SSR demo, using only ES5 with no build step.

## Usage

``` sh
npm install # install dependencies
```

``` sh
npm run dev # run server in development
```

``` sh
npm run prod # run server in production
```
