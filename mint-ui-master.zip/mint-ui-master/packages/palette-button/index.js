export { default } from './src/palette-button.vue';
