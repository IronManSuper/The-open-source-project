import 'mint-ui/src/style/empty.css';
export { default } from './src/infinite-scroll.js';
